-- 1. Top 5 funds by latest available AUM
WITH latest AS (
  SELECT fund_key, MAX(date_key) AS max_date FROM fact_aum GROUP BY fund_key
)
SELECT f.scheme_name, a.aum
FROM fact_aum a
JOIN latest l ON a.fund_key=l.fund_key AND a.date_key=l.max_date
JOIN dim_fund f ON f.fund_key=a.fund_key
ORDER BY a.aum DESC LIMIT 5;

-- 2. Average NAV per month
SELECT d.year, d.month, ROUND(AVG(n.nav), 4) AS avg_nav
FROM fact_nav n JOIN dim_date d ON n.date_key=d.date_key
GROUP BY d.year, d.month ORDER BY d.year, d.month;

-- 3. SIP year-over-year growth (amount)
WITH yearly AS (
  SELECT d.year, SUM(t.amount) AS sip_amount
  FROM fact_transactions t JOIN dim_date d ON t.date_key=d.date_key
  WHERE t.transaction_type='SIP' GROUP BY d.year
)
SELECT year, sip_amount,
       ROUND(100.0*(sip_amount-LAG(sip_amount) OVER (ORDER BY year)) /
       NULLIF(LAG(sip_amount) OVER (ORDER BY year),0), 2) AS yoy_growth_pct
FROM yearly ORDER BY year;

-- 4. Transaction count and amount by state
SELECT state, COUNT(*) AS transaction_count, SUM(amount) AS total_amount
FROM fact_transactions GROUP BY state ORDER BY total_amount DESC;

-- 5. Funds with expense ratio below 1%
SELECT f.scheme_name, p.expense_ratio
FROM fact_performance p JOIN dim_fund f ON p.fund_key=f.fund_key
WHERE p.expense_ratio < 1 ORDER BY p.expense_ratio;

-- 6. Transaction mix by transaction type
SELECT transaction_type, COUNT(*) AS txn_count, SUM(amount) AS total_amount
FROM fact_transactions GROUP BY transaction_type ORDER BY total_amount DESC;

-- 7. Monthly redemption amount
SELECT d.year, d.month, SUM(t.amount) AS redemption_amount
FROM fact_transactions t JOIN dim_date d ON t.date_key=d.date_key
WHERE t.transaction_type='Redemption'
GROUP BY d.year, d.month ORDER BY d.year, d.month;

-- 8. Average 1-year, 3-year and 5-year returns
SELECT f.scheme_name, AVG(p.return_1y) AS avg_1y,
       AVG(p.return_3y) AS avg_3y, AVG(p.return_5y) AS avg_5y
FROM fact_performance p JOIN dim_fund f ON p.fund_key=f.fund_key
GROUP BY f.scheme_name ORDER BY avg_3y DESC;

-- 9. Funds with highest latest NAV
WITH latest AS (
  SELECT fund_key, MAX(date_key) AS max_date FROM fact_nav GROUP BY fund_key
)
SELECT f.scheme_name, n.nav
FROM fact_nav n JOIN latest l ON n.fund_key=l.fund_key AND n.date_key=l.max_date
JOIN dim_fund f ON f.fund_key=n.fund_key
ORDER BY n.nav DESC LIMIT 10;

-- 10. KYC status summary
SELECT COALESCE(kyc_status,'UNKNOWN') AS kyc_status,
       COUNT(*) AS transaction_count, SUM(amount) AS transaction_amount
FROM fact_transactions GROUP BY COALESCE(kyc_status,'UNKNOWN')
ORDER BY transaction_count DESC;
